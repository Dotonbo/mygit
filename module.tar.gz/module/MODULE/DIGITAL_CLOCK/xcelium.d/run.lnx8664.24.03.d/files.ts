1732173284 /home/yhjeong/cds.lib
1733201057 /home/yhjeong/module/MODULE/DIGITAL_CLOCK/Digital_Clock.v
1733201100 /home/yhjeong/module/MODULE/DIGITAL_CLOCK/Segment7_Decoder.v
1733201235 /home/yhjeong/module/MODULE/DIGITAL_CLOCK/tb_Digital_Clock.v
